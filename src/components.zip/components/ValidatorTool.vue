<template>
  <main role="main" class="container">
    <div style="padding-top: 7rem" class="d-none d-lg-block"></div>
    <div class="row justify-content-md-center">
      <div class="col-lg-4">
        <div class="text-center vstack gap-3">
          <h1>Validator tool</h1>
          <div id="reader" width="400px"></div>
          <input type="text" placeholder="commitment" v-model="commitment" />
          <input type="text" placeholder="unique hash" v-model="uniqueHash" />
          <button class="btn btn-info" @click="sendToBlockchain">
            Send to blockchain
          </button>
          <a href="#/" class="btn btn-primary">Back</a>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import { ref, onMounted, onBeforeUnmount } from "vue";
import { Html5QrcodeScanner } from "html5-qrcode";
import * as ethers from "ethers";

export default {
  setup() {
    const commitment = ref("");
    const uniqueHash = ref("");
    let html5QrcodeScanner = null;

    // Initialize QR code scanner
    onMounted(() => {
      html5QrcodeScanner = new Html5QrcodeScanner(
        "reader",
        { fps: 10, qrbox: { width: 400, height: 400 } },
        false
      );
      html5QrcodeScanner.render(
        (decodedText) => {
          commitment.value = decodedText.trim(); // Simpan hasil decoding ke state
        },
        (error) => {
          console.error("QR Scanner Error:", error); // Tangani error decoding
        }
      );
    });

    // Clean up QR code scanner instance
    onBeforeUnmount(() => {
      if (html5QrcodeScanner) {
        html5QrcodeScanner.clear();
        html5QrcodeScanner = null;
      }
    });

    const sendToBlockchain = async () => {
      const abi = [
        "function registerCommitment(uint256 _uniqueHash, uint256 _commitment)",
      ];
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      const signer = provider.getSigner();

      try {
        const contracts = await (await fetch("contracts.json")).json();
        const contract = new ethers.Contract(contracts.zktreevote, abi, signer);

        // Validasi input
        if (!commitment.value || !uniqueHash.value) {
          alert("Both commitment and unique hash are required.");
          return;
        }

        // Pastikan data dalam format yang benar
        const commitmentValue = ethers.BigNumber.from(commitment.value);
        const uniqueHashValue = ethers.BigNumber.from(uniqueHash.value);

        // Kirim transaksi ke blockchain
        await contract.registerCommitment(uniqueHashValue, commitmentValue);
        alert("Transaction sent successfully!");
      } catch (error) {
        const reason = error.reason || "An unknown error occurred.";
        console.error("Blockchain Error:", error);
        alert(reason);
      }
    };

    return { commitment, uniqueHash, sendToBlockchain };
  },
};
</script>
