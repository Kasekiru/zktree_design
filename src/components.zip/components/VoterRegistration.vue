<template>
  <main role="main" class="container">
    <div style="padding-top: 7rem" class="d-none d-lg-block"></div>
    <div class="row justify-content-md-center">
      <div class="col-lg-4">
        <div class="text-center vstack gap-3">
          <h1>Your commitment</h1>
          <img :src="qrcodeDataUrl" />
          <div v-if="commitment" v-html="splitTwoLines(commitment.commitment)"></div>
          <button class="btn btn-info" @click="copyToClipboard">
            Copy to clipboard
          </button>
          <button class="btn btn-danger" @click="resetCommitment">
            Reset commitment
          </button>
          <a href="#/" class="btn btn-primary">Back</a>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import { ref, onMounted } from "vue";
import { generateCommitment } from "zk-merkle-tree";
import QRCode from "qrcode";
import copyToClipboard from "copy-to-clipboard";

export default {
  setup() {
    const commitment = ref(null);
    const qrcodeDataUrl = ref("");

    // Initialization logic to load or generate commitment
    const init = async () => {
      commitment.value = JSON.parse(localStorage.getItem("zktree-vote-commitment"));
      if (!commitment.value) {
        commitment.value = await generateCommitment();
        localStorage.setItem("zktree-vote-commitment", JSON.stringify(commitment.value));
      }
      qrcodeDataUrl.value = await QRCode.toDataURL(commitment.value.commitment);
    };

    // Lifecycle hook to run init on component mount
    onMounted(init);

    // Function to split the commitment text into two lines
    const splitTwoLines = (text) => {
      const half = text.length / 2;
      return (
        text.substring(0, half) + "<br/>" + text.substring(half + 1, text.length)
      );
    };

    // Function to copy the commitment to the clipboard
    const copyToClipboardFn = () => {
      copyToClipboard(commitment.value.commitment);
      alert("Successfully copied to the clipboard");
    };

    // Function to reset the commitment
    const resetCommitment = () => {
      localStorage.removeItem("zktree-vote-commitment");
      init();
    };

    return {
      commitment,
      qrcodeDataUrl,
      splitTwoLines,
      copyToClipboard: copyToClipboardFn,
      resetCommitment,
    };
  },
};
</script>
